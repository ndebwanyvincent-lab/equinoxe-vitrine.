// Configuration publique du site Équinoxe Services.
// Ces clés sont faites pour être publiques : la sécurité est assurée par les règles de la base (RLS).
export const SUPABASE_URL = "https://xxfzvowptsfpzrlbwvkq.supabase.co";
export const SUPABASE_KEY = "sb_publishable_pd8Pc_44u0_phAeSS-posg_f95-Jceg";

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

export const DEFAULT_SETTINGS = {
  whatsapp_number: "+243 836 963 894",
  slogan: "L'art de créer des souvenirs.",
  elevenlabs_agent_id: "agent_8001m6w4h06sfzs9nyhabttvx0rw",
};

export const waDigits = (n) => (n || "").replace(/\D/g, "");
export const waLink = (number, text) =>
  "https://wa.me/" + waDigits(number) + "?text=" + encodeURIComponent(text);
export const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
