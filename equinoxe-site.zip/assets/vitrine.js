import { supabase, DEFAULT_SETTINGS, waLink, esc } from "./config.js";

const $ = (id) => document.getElementById(id);
let settings = { ...DEFAULT_SETTINGS };
let sections = [];
let cur = null; // rubrique affichée

const ICON_EYE_S = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const ICON_EYE = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const ICON_DL = '<svg width="17" height="19" viewBox="0 0 22 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 3v13M5 11l6 6 6-6M3 22h16"/></svg>';
const CHEV_R = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 3l5 5-5 5"/></svg>';
const CHEV_L = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M10 3L5 8l5 5"/></svg>';

const thumbOf = (it) => it.media_type === "video" ? (it.poster_url || "") : (it.media_url || "");
const orderMsg = (it) => `Bonjour ÉQUINOXE EVENTS, je suis intéressé(e) par le modèle « ${it.name} » (${cur.name}).`;
const infoMsg = () => `Bonjour ÉQUINOXE EVENTS, je souhaite des informations sur vos ${cur ? cur.name.toLowerCase() : "services"}.`;

/* ---------- Données ---------- */
async function load() {
  const [st, sec, its] = await Promise.all([
    supabase.from("settings").select("*").eq("id", 1).maybeSingle(),
    supabase.from("sections").select("*").eq("visible", true).order("position"),
    supabase.from("items").select("*").eq("visible", true).order("position"),
  ]);
  if (st.data) settings = { ...settings, ...st.data };
  if (sec.error || its.error) {
    $("card").innerHTML = '<div class="loading">Impossible de charger les modèles. Vérifiez votre connexion puis rechargez la page.</div>';
    return;
  }
  sections = (sec.data || []).map((s) => ({ ...s, items: (its.data || []).filter((i) => i.section_id === s.id) }));
  $("num").textContent = settings.whatsapp_number;
  $("sloganLine").textContent = "ÉQUINOXE EVENTS · " + settings.slogan;
  let saved = null; try { saved = localStorage.getItem("eq-tab"); } catch (e) {}
  cur = sections.find((s) => s.id === saved) || sections[0] || null;
  render();
}

/* ---------- Rendu ---------- */
function renderTabs() {
  $("tabs").innerHTML = sections.map((s) =>
    `<button class="tab" role="tab" aria-selected="${s === cur}" data-id="${s.id}">${esc(s.name)}</button>`).join("");
  $("tabs").querySelectorAll(".tab").forEach((b) => b.onclick = () => select(b.dataset.id));
  const on = $("tabs").querySelector('[aria-selected="true"]');
  on?.scrollIntoView({ inline: "nearest", block: "nearest" });
}

function select(id) {
  cur = sections.find((s) => s.id === id) || cur;
  try { localStorage.setItem("eq-tab", cur.id); } catch (e) {}
  render();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function slideHtml(it, i) {
  let media;
  if (it.media_type === "video" && it.media_url) {
    media = `<video src="${esc(it.media_url)}" ${it.poster_url ? `poster="${esc(it.poster_url)}"` : ""} controls playsinline preload="none"></video>`;
  } else if (it.media_url) {
    media = `<img src="${esc(it.media_url)}" alt="${esc(it.name)}" ${i ? 'loading="lazy"' : ""}>`;
  } else {
    media = `<div class="ph">${esc(it.name)}</div>`;
  }
  const pill = it.link_url ? `<a class="pill" href="${esc(it.link_url)}" target="_blank" rel="noopener">${ICON_EYE_S}Ouvrir</a>` : "";
  return `<div class="slide">${media}${pill}</div>`;
}

function render() {
  renderTabs();
  const card = $("card");
  if (!cur) { card.innerHTML = '<div class="loading">Aucune rubrique pour le moment.</div>'; return; }
  const items = cur.items;
  let html = "";
  if (items.length) {
    html += `<div class="car"><div class="track" id="track">${items.map(slideHtml).join("")}</div>
      <button class="arr prev" id="prev" aria-label="Modèle précédent" hidden>${CHEV_L}</button>
      <button class="arr next" id="next" aria-label="Modèle suivant" ${items.length < 2 ? "hidden" : ""}>${CHEV_R}</button>
      <div class="cap"><b id="capName">${esc(items[0].name)}</b><span class="dots" id="dots">${items.length > 1 ? items.map((_, i) => `<i class="${i ? "" : "on"}"></i>`).join("") : ""}</span></div></div>`;
  }
  html += `<h1>${esc(cur.title || cur.name)}</h1>`;
  if (items.length) {
    html += `<div class="list">${items.map((it, i) => `<div class="item">
      ${thumbOf(it) ? `<img class="thumb" src="${esc(thumbOf(it))}" alt="" loading="lazy">` : '<span class="thumb"></span>'}
      <div class="name">${esc(it.name)}</div>
      ${it.link_url ? `<a class="ico" aria-label="Voir ${esc(it.name)}" target="_blank" rel="noopener" href="${esc(it.link_url)}">${ICON_EYE}</a>`
                    : `<button class="ico" aria-label="Voir ${esc(it.name)}" data-i="${i}">${ICON_EYE}</button>`}
      <a class="ico go" aria-label="Commander ${esc(it.name)}" target="_blank" rel="noopener" href="${waLink(settings.whatsapp_number, orderMsg(it))}">${ICON_DL}</a>
    </div>`).join("")}</div>`;
  }
  html += `<div class="btns">
    ${items.length ? `<button class="btn out" id="openGrid">${ICON_EYE}Ouvrir</button>` : ""}
    <a class="btn full" target="_blank" rel="noopener" href="${waLink(settings.whatsapp_number, infoMsg())}">Commander sur WhatsApp</a></div>`;
  card.innerHTML = html;
  card.querySelectorAll("button.ico").forEach((b) => b.onclick = () => showSlide(+b.dataset.i));
  $("openGrid") && ($("openGrid").onclick = openGrid);
  wireCarousel();
}

function wireCarousel() {
  const tr = $("track"); if (!tr) return;
  const n = cur.items.length;
  const idx = () => Math.round(tr.scrollLeft / tr.clientWidth);
  $("next").onclick = () => tr.scrollBy({ left: tr.clientWidth, behavior: "smooth" });
  $("prev").onclick = () => tr.scrollBy({ left: -tr.clientWidth, behavior: "smooth" });
  const upd = () => {
    const i = Math.min(idx(), n - 1);
    $("prev").hidden = i <= 0; $("next").hidden = i >= n - 1;
    $("capName").textContent = cur.items[i].name;
    $("dots").querySelectorAll("i").forEach((d, k) => d.className = k === i ? "on" : "");
    tr.querySelectorAll("video").forEach((v, k) => { if (k !== i && !v.paused) v.pause(); });
  };
  tr.addEventListener("scroll", () => requestAnimationFrame(upd), { passive: true });
  tr.querySelectorAll("video").forEach((v) => v.addEventListener("play", () =>
    tr.querySelectorAll("video").forEach((o) => { if (o !== v) o.pause(); })));
}

function showSlide(i) {
  closeScreens();
  const tr = $("track"); if (!tr) return;
  $("card").scrollIntoView({ behavior: "smooth", block: "start" });
  const slide = tr.children[i];
  tr.scrollTo({ left: i * tr.clientWidth, behavior: "smooth" });
  const v = slide?.querySelector("video");
  if (v) setTimeout(() => v.play().catch(() => {}), 450);
}

function openGrid() {
  $("gTitle").textContent = cur.name;
  $("grid").innerHTML = cur.items.map((it, i) => {
    const img = thumbOf(it) ? `<img src="${esc(thumbOf(it))}" alt="" loading="lazy">` : `<div class="ph" style="font-size:18px">${esc(it.name)}</div>`;
    return it.link_url
      ? `<a class="tile" href="${esc(it.link_url)}" target="_blank" rel="noopener">${img}<span>${esc(it.name)}</span></a>`
      : `<button class="tile" data-i="${i}">${img}<span>${esc(it.name)}</span></button>`;
  }).join("");
  $("grid").querySelectorAll("button.tile").forEach((b) => b.onclick = () => showSlide(+b.dataset.i));
  $("gridView").hidden = false;
}

function openMenu() {
  $("menulist").innerHTML = sections.map((s) =>
    `<button class="mi${s === cur ? " on" : ""}" data-id="${s.id}"><span>${esc(s.name)}</span>${CHEV_R}</button>`).join("");
  $("menulist").querySelectorAll(".mi").forEach((b) => b.onclick = () => { closeScreens(); select(b.dataset.id); });
  $("menuWa").href = waLink(settings.whatsapp_number, "Bonjour ÉQUINOXE EVENTS, je souhaite des informations sur vos services.");
  $("menu").hidden = false;
}
function closeScreens() { $("menu").hidden = true; $("gridView").hidden = true; }

$("burger").onclick = openMenu;
$("menuClose").onclick = closeScreens;
$("gridClose").onclick = closeScreens;
$("copyBtn").onclick = () => {
  navigator.clipboard?.writeText(settings.whatsapp_number)
    .then(() => $("copyBtn").textContent = "Numéro copié")
    .catch(() => { const r = document.createRange(); r.selectNodeContents($("num")); const s = getSelection(); s.removeAllRanges(); s.addRange(r); });
};
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeScreens(); });

/* ---------- Grâce : appel vocal dans la page ---------- */
let conv = null, state = "idle", muted = false, t0 = 0, tick = null;

function setView(v) {
  state = v;
  $("call").hidden = v === "idle" || v === "minimized";
  $("bubble").hidden = v !== "minimized";
  $("ringActions").hidden = v !== "ringing";
  $("errActions").hidden = v !== "error";
  $("inCallActions").hidden = !(v === "connecting" || v === "incall");
  $("timer").hidden = v !== "incall";
  $("callKicker").textContent = v === "ringing" ? "Appel entrant" : v === "error" ? "Appel interrompu" : "En ligne";
  if (v === "ringing") $("callStatus").textContent = "Équinoxe Events vous appelle…";
  if (v === "connecting") $("callStatus").textContent = "Connexion…";
  document.body.style.overflow = $("call").hidden ? "" : "hidden";
}

function ring() { if (state === "idle") setView("ringing"); }

async function answer() {
  if (state === "connecting" || state === "incall") return;
  setView("connecting");
  try {
    // Le téléphone demande l'accès au micro (une seule fois par site).
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((t) => t.stop());
  } catch (e) {
    return fail("Pour parler avec Grâce, autorisez le micro de votre téléphone, puis appuyez sur « Réessayer ».");
  }
  try {
    // Bibliothèque officielle ElevenLabs, chargée seulement au moment de l'appel.
    const { Conversation } = await import("https://esm.sh/@elevenlabs/client");
    conv = await Conversation.startSession({
      agentId: settings.elevenlabs_agent_id,
      onConnect: () => {
        setView("incall"); t0 = Date.now();
        clearInterval(tick);
        tick = setInterval(() => {
          const s = Math.floor((Date.now() - t0) / 1000);
          $("timer").textContent = String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
        }, 1000);
      },
      onDisconnect: () => endUi(),
      onError: () => fail("La communication avec Grâce a été coupée. Vérifiez votre connexion internet puis réessayez."),
      onModeChange: ({ mode }) => {
        const speaking = mode === "speaking";
        $("bigorb").classList.toggle("speaking", speaking);
        if (state === "incall") $("callStatus").textContent = speaking ? "Grâce vous parle…" : "Je vous écoute…";
        $("bubble").querySelector("span:last-child").textContent = speaking ? "Grâce parle…" : "Grâce · en ligne";
      },
    });
  } catch (e) {
    fail("Grâce n'est pas joignable pour le moment. Réessayez dans un instant ou écrivez-nous sur WhatsApp.");
  }
}

function fail(msg) {
  try { conv?.endSession(); } catch (e) {}
  conv = null; clearInterval(tick);
  $("errText").textContent = msg;
  $("errWa").href = waLink(settings.whatsapp_number, "Bonjour ÉQUINOXE EVENTS, je souhaite des informations sur vos services.");
  setView("error");
}

function endUi() {
  conv = null; clearInterval(tick);
  $("bigorb").classList.remove("speaking");
  muted = false; $("muteBtn").classList.remove("on"); $("muteLbl").textContent = "Couper le micro";
  if (state !== "error") setView("idle");
}

async function hangUp() { const c = conv; conv = null; try { await c?.endSession(); } catch (e) {} endUi(); setView("idle"); }

$("answerBtn").onclick = (e) => { e.stopPropagation(); answer(); };
$("call").addEventListener("click", (e) => {
  // Toucher n'importe où pendant la sonnerie = répondre
  if (state === "ringing" && !e.target.closest("#laterBtn")) answer();
});
$("laterBtn").onclick = (e) => { e.stopPropagation(); setView("idle"); };
$("retryBtn").onclick = () => answer();
$("errClose").onclick = () => setView("idle");
$("hangBtn").onclick = hangUp;
$("minBtn").onclick = () => setView("minimized");
$("bubble").onclick = () => setView(conv ? "incall" : "idle");
$("muteBtn").onclick = () => {
  if (!conv || typeof conv.setMicMuted !== "function") return;
  muted = !muted; conv.setMicMuted(muted);
  $("muteBtn").classList.toggle("on", muted);
  $("muteLbl").textContent = muted ? "Réactiver le micro" : "Couper le micro";
};
const startCall = () => { closeScreens(); if (conv) setView("incall"); else { setView("ringing"); answer(); } };
$("graceBtn").onclick = startCall;
$("menuGrace").onclick = startCall;
window.addEventListener("pagehide", () => { try { conv?.endSession(); } catch (e) {} });

/* ---------- Démarrage ---------- */
load();
let rang = false; try { rang = sessionStorage.getItem("eq-rang") === "1"; } catch (e) {}
if (!rang) {
  setTimeout(() => { ring(); try { sessionStorage.setItem("eq-rang", "1"); } catch (e) {} }, 900);
}
