import { supabase, SUPABASE_URL, SUPABASE_KEY, DEFAULT_SETTINGS, esc } from "./config.js";

const app = document.getElementById("app");
const $ = (id) => document.getElementById(id);
let session = null;
let sections = [];
let items = [];
let settings = { ...DEFAULT_SETTINGS };
let view = { name: "home" }; // home | section | item | settings

const I = {
  up: '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3 10l5-5 5 5"/></svg>',
  down: '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M3 6l5 5 5-5"/></svg>',
  edit: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 20h4L19 9l-4-4L4 16v4z"/></svg>',
  del: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  eye: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  hide: '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3.2 3.9M6.6 6.6A17 17 0 0 0 2 12s3.5 7 10 7a9.6 9.6 0 0 0 5.4-1.6"/></svg>',
  back: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M10 3L5 8l5 5"/></svg>',
};

function toast(msg) {
  const t = document.createElement("div"); t.className = "toast"; t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), 2600);
}
const fail = (e, what) => { console.error(e); toast(`${what} : échec. ${e?.message || "Vérifiez votre connexion."}`); };

/* ---------- Connexion ---------- */
function loginView(mode = "in", note = "") {
  $("topActions").hidden = true;
  app.innerHTML = `
  <div class="panel">
    <b style="font-size:17px;font-weight:500">${mode === "in" ? "Connexion à la gestion" : "Créer le compte administrateur"}</b>
    <p class="hint">${mode === "in" ? "Entrez l'adresse e-mail et le mot de passe de votre compte." : "Le tout premier compte créé devient administrateur. Les comptes créés ensuite n'auront aucun droit."}</p>
    ${note ? `<p class="hint" style="color:var(--gold-soft)">${esc(note)}</p>` : ""}
    <form id="authForm" style="display:flex;flex-direction:column;gap:10px">
      <label class="field">Adresse e-mail<input id="email" type="email" autocomplete="email" required></label>
      <label class="field">Mot de passe<input id="pwd" type="password" autocomplete="${mode === "in" ? "current-password" : "new-password"}" minlength="8" required></label>
      <button class="btn full" type="submit" id="authBtn">${mode === "in" ? "Se connecter" : "Créer le compte"}</button>
    </form>
    <button class="btn ghost" id="switchMode">${mode === "in" ? "Première utilisation ? Créer le compte administrateur" : "J'ai déjà un compte"}</button>
  </div>`;
  $("switchMode").onclick = () => loginView(mode === "in" ? "up" : "in");
  $("authForm").onsubmit = async (e) => {
    e.preventDefault();
    const email = $("email").value.trim(), password = $("pwd").value;
    $("authBtn").disabled = true;
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      $("authBtn").disabled = false;
      if (error) return loginView("in", error.message.includes("confirm") ? "Confirmez d'abord votre adresse avec le lien reçu par e-mail." : "E-mail ou mot de passe incorrect.");
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: location.origin + "/admin" } });
      $("authBtn").disabled = false;
      if (error) return loginView("up", "Création impossible : " + error.message);
      if (!data.session) return loginView("in", "Compte créé. Ouvrez le lien de confirmation reçu par e-mail, puis connectez-vous ici.");
    }
  };
}

async function isAdmin() {
  const { data } = await supabase.from("user_roles").select("role").eq("user_id", session.user.id).eq("role", "admin").maybeSingle();
  return !!data;
}

/* ---------- Données ---------- */
async function loadAll() {
  const [s, i, st] = await Promise.all([
    supabase.from("sections").select("*").order("position"),
    supabase.from("items").select("*").order("position"),
    supabase.from("settings").select("*").eq("id", 1).maybeSingle(),
  ]);
  if (s.error || i.error) throw s.error || i.error;
  sections = s.data || []; items = i.data || []; if (st.data) settings = st.data;
}
const itemsOf = (sid) => items.filter((x) => x.section_id === sid).sort((a, b) => a.position - b.position);

async function swap(table, list, idx, dir) {
  const a = list[idx], b = list[idx + dir]; if (!a || !b) return;
  const pa = a.position, pb = b.position === pa ? pa + dir : b.position;
  const r1 = await supabase.from(table).update({ position: pb }).eq("id", a.id);
  const r2 = await supabase.from(table).update({ position: pa }).eq("id", b.id);
  if (r1.error || r2.error) return fail(r1.error || r2.error, "Déplacement");
  await refresh();
}

async function refresh() { try { await loadAll(); } catch (e) { return fail(e, "Chargement"); } render(); }

/* ---------- Envoi de fichiers (avec progression) ---------- */
function uploadFile(file, onProgress) {
  return new Promise((resolve, reject) => {
    const ext = (file.name.split(".").pop() || "bin").toLowerCase().replace(/[^a-z0-9]/g, "");
    const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${SUPABASE_URL}/storage/v1/object/media/${path}`);
    xhr.setRequestHeader("Authorization", "Bearer " + session.access_token);
    xhr.setRequestHeader("apikey", SUPABASE_KEY);
    xhr.setRequestHeader("x-upsert", "false");
    xhr.setRequestHeader("Content-Type", file.type || "application/octet-stream");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(e.loaded / e.total);
    xhr.onload = () => xhr.status < 300 ? resolve(`${SUPABASE_URL}/storage/v1/object/public/media/${path}`)
      : reject(new Error(xhr.status === 413 ? "Fichier trop lourd (50 Mo maximum)." : "Erreur " + xhr.status));
    xhr.onerror = () => reject(new Error("Connexion perdue pendant l'envoi."));
    xhr.send(file);
  });
}
async function removeStored(url) {
  const pre = `${SUPABASE_URL}/storage/v1/object/public/media/`;
  if (url && url.startsWith(pre)) await supabase.storage.from("media").remove([url.slice(pre.length)]);
}

/* ---------- Vues ---------- */
function render() {
  $("topActions").hidden = false;
  if (view.name === "section") return sectionView();
  if (view.name === "item") return itemView();
  if (view.name === "settings") return settingsView();
  homeView();
}
const go = (v) => { view = v; render(); window.scrollTo(0, 0); };

function homeView() {
  const site = location.origin + "/";
  app.innerHTML = `
  <div class="panel">
    <b style="font-weight:500">Lien de la vitrine à envoyer aux clients</b>
    <div class="row"><code style="flex:1;font-size:13px;color:var(--gold-soft);word-break:break-all;user-select:all" id="siteUrl">${esc(site)}</code><button class="btn out" id="copySite" style="height:36px">Copier</button></div>
  </div>
  <div class="panel">
    <div class="row" style="justify-content:space-between"><b style="font-weight:500">Rubriques</b><button class="btn full" id="addSec" style="height:36px">+ Ajouter</button></div>
    <div id="newSec" hidden style="display:flex;flex-direction:column;gap:8px">
      <label class="field">Nom de la rubrique (onglet)<input id="secName" placeholder="Ex. Décoration"></label>
      <div class="row"><button class="btn full" id="secCreate" style="flex:1">Créer</button><button class="btn ghost" id="secCancel">Annuler</button></div>
    </div>
    ${sections.map((s, i) => `<div class="sec">
      <div class="nm" data-open="${s.id}" style="cursor:pointer"><b>${esc(s.name)}</b><small>${itemsOf(s.id).length} élément(s)${s.visible ? "" : " · masquée"}</small></div>
      <button class="mini" data-up="${i}" aria-label="Monter" ${i ? "" : "disabled"}>${I.up}</button>
      <button class="mini" data-down="${i}" aria-label="Descendre" ${i < sections.length - 1 ? "" : "disabled"}>${I.down}</button>
      <button class="mini" data-open="${s.id}" aria-label="Modifier">${I.edit}</button>
    </div>`).join("")}
  </div>
  <button class="btn ghost" id="toSettings">Réglages : WhatsApp, slogan, assistante</button>`;
  $("copySite").onclick = () => navigator.clipboard?.writeText(site).then(() => toast("Lien copié")).catch(() => toast("Sélectionnez le lien pour le copier"));
  $("addSec").onclick = () => { $("newSec").hidden = false; $("secName").focus(); };
  $("secCancel").onclick = () => $("newSec").hidden = true;
  $("secCreate").onclick = async () => {
    const name = $("secName").value.trim(); if (!name) return toast("Donnez un nom à la rubrique");
    const pos = Math.max(0, ...sections.map((s) => s.position)) + 1;
    const { error } = await supabase.from("sections").insert({ name, title: name, position: pos });
    if (error) return fail(error, "Création"); toast("Rubrique créée"); refresh();
  };
  app.querySelectorAll("[data-open]").forEach((b) => b.onclick = () => go({ name: "section", id: b.dataset.open }));
  app.querySelectorAll("[data-up]").forEach((b) => b.onclick = () => swap("sections", sections, +b.dataset.up, -1));
  app.querySelectorAll("[data-down]").forEach((b) => b.onclick = () => swap("sections", sections, +b.dataset.down, 1));
  $("toSettings").onclick = () => go({ name: "settings" });
}

function sectionView() {
  const s = sections.find((x) => x.id === view.id); if (!s) return go({ name: "home" });
  const list = itemsOf(s.id);
  app.innerHTML = `
  <button class="btn ghost" id="back" style="align-self:flex-start;height:34px">${I.back} Rubriques</button>
  <div class="panel">
    <label class="field">Nom de l'onglet<input id="sName" value="${esc(s.name)}"></label>
    <label class="field">Titre affiché aux clients<textarea id="sTitle" rows="2">${esc(s.title)}</textarea></label>
    <label class="switch"><input type="checkbox" id="sVisible" ${s.visible ? "checked" : ""}> Visible sur la vitrine</label>
    <button class="btn full" id="sSave">Enregistrer</button>
  </div>
  <div class="panel">
    <div class="row" style="justify-content:space-between"><b style="font-weight:500">Photos, vidéos et modèles</b><button class="btn full" id="addItem" style="height:36px">+ Ajouter</button></div>
    ${list.length ? "" : '<p class="hint">Aucun élément. Appuyez sur « + Ajouter » pour mettre une photo ou une vidéo.</p>'}
    ${list.map((it, i) => {
      const th = it.media_type === "video" ? it.poster_url : it.media_url;
      return `<div class="sec">
        ${th ? `<img class="thumb" src="${esc(th)}" alt="">` : '<span class="thumb"></span>'}
        <div class="nm" data-edit="${it.id}" style="cursor:pointer"><b>${esc(it.name)}</b><small>${it.media_type === "video" ? "Vidéo" : "Photo"}${it.link_url ? " · lien" : ""}${it.visible ? "" : " · masqué"}</small></div>
        <button class="mini" data-up="${i}" aria-label="Monter" ${i ? "" : "disabled"}>${I.up}</button>
        <button class="mini" data-down="${i}" aria-label="Descendre" ${i < list.length - 1 ? "" : "disabled"}>${I.down}</button>
        <button class="mini" data-edit="${it.id}" aria-label="Modifier">${I.edit}</button>
      </div>`; }).join("")}
  </div>
  <div class="panel">
    <button class="btn danger" id="sDel">Supprimer cette rubrique</button>
    <div class="confirm" id="sDelBox" hidden>Supprimer « ${esc(s.name)} » et ses ${list.length} élément(s) ? Cette action est définitive.
      <div class="row"><button class="btn danger" id="sDelYes" style="flex:1">Oui, supprimer</button><button class="btn ghost" id="sDelNo">Annuler</button></div></div>
  </div>`;
  $("back").onclick = () => go({ name: "home" });
  $("sSave").onclick = async () => {
    const { error } = await supabase.from("sections").update({ name: $("sName").value.trim() || s.name, title: $("sTitle").value.trim(), visible: $("sVisible").checked }).eq("id", s.id);
    if (error) return fail(error, "Enregistrement"); toast("Enregistré"); refresh();
  };
  $("addItem").onclick = () => go({ name: "item", sectionId: s.id, id: null });
  app.querySelectorAll("[data-edit]").forEach((b) => b.onclick = () => go({ name: "item", sectionId: s.id, id: b.dataset.edit }));
  app.querySelectorAll("[data-up]").forEach((b) => b.onclick = () => swap("items", list, +b.dataset.up, -1));
  app.querySelectorAll("[data-down]").forEach((b) => b.onclick = () => swap("items", list, +b.dataset.down, 1));
  $("sDel").onclick = () => $("sDelBox").hidden = false;
  $("sDelNo").onclick = () => $("sDelBox").hidden = true;
  $("sDelYes").onclick = async () => {
    for (const it of list) { await removeStored(it.media_url); await removeStored(it.poster_url); }
    const { error } = await supabase.from("sections").delete().eq("id", s.id);
    if (error) return fail(error, "Suppression"); toast("Rubrique supprimée"); view = { name: "home" }; refresh();
  };
}

function itemView() {
  const it = view.id ? items.find((x) => x.id === view.id) : null;
  const sec = sections.find((x) => x.id === view.sectionId);
  let media = { type: it?.media_type || "image", url: it?.media_url || "", poster: it?.poster_url || "" };
  app.innerHTML = `
  <button class="btn ghost" id="back" style="align-self:flex-start;height:34px">${I.back} ${esc(sec?.name || "Retour")}</button>
  <div class="panel">
    <b style="font-weight:500">${it ? "Modifier" : "Ajouter"} un élément</b>
    <label class="field">Nom (ex. Soirée élégante, Photo 1)<input id="iName" value="${esc(it?.name || "")}"></label>
    <div class="field">Photo ou vidéo
      <div id="mPrev"></div>
      <input type="file" id="iFile" accept="image/*,video/*">
      <div class="bar" id="bar" hidden><i id="barFill"></i></div>
      <p class="hint">Photos JPG ou PNG. Vidéos MP4 de préférence, 50 Mo maximum.</p>
    </div>
    <div class="field" id="posterBox" hidden>Image de couverture de la vidéo (facultatif)
      <input type="file" id="iPoster" accept="image/*">
    </div>
    <label class="field">Lien à ouvrir (facultatif, ex. une vraie invitation digitale)<input id="iLink" type="url" placeholder="https://…" value="${esc(it?.link_url || "")}"></label>
    <label class="switch"><input type="checkbox" id="iVisible" ${it?.visible === false ? "" : "checked"}> Visible sur la vitrine</label>
    <button class="btn full" id="iSave">Enregistrer</button>
  </div>
  ${it ? `<div class="panel"><button class="btn danger" id="iDel">Supprimer cet élément</button>
    <div class="confirm" id="iDelBox" hidden>Supprimer « ${esc(it.name)} » ? Cette action est définitive.
    <div class="row"><button class="btn danger" id="iDelYes" style="flex:1">Oui, supprimer</button><button class="btn ghost" id="iDelNo">Annuler</button></div></div></div>` : ""}`;
  const showPrev = () => {
    $("mPrev").innerHTML = media.url
      ? (media.type === "video" ? `<video class="prev" src="${esc(media.url)}" ${media.poster ? `poster="${esc(media.poster)}"` : ""} controls playsinline preload="metadata"></video>`
                                : `<img class="prev" src="${esc(media.url)}" alt="">`)
      : '<p class="hint">Aucun fichier pour le moment.</p>';
    $("posterBox").hidden = media.type !== "video";
  };
  showPrev();
  const busy = (on) => { $("iSave").disabled = on; $("bar").hidden = !on; if (!on) $("barFill").style.width = "0"; };
  $("iFile").onchange = async () => {
    const f = $("iFile").files[0]; if (!f) return;
    if (f.size > 50 * 1024 * 1024) { $("iFile").value = ""; return toast("Fichier trop lourd : 50 Mo maximum."); }
    busy(true);
    try {
      const url = await uploadFile(f, (p) => $("barFill").style.width = Math.round(p * 100) + "%");
      media = { type: f.type.startsWith("video") ? "video" : "image", url, poster: f.type.startsWith("video") ? media.poster : "" };
      if (!$("iName").value.trim()) $("iName").value = f.name.replace(/\.[^.]+$/, "");
      showPrev(); toast("Fichier envoyé");
    } catch (e) { fail(e, "Envoi"); }
    busy(false);
  };
  $("iPoster").onchange = async () => {
    const f = $("iPoster").files[0]; if (!f) return;
    busy(true);
    try { media.poster = await uploadFile(f, (p) => $("barFill").style.width = Math.round(p * 100) + "%"); showPrev(); toast("Couverture envoyée"); }
    catch (e) { fail(e, "Envoi"); }
    busy(false);
  };
  $("back").onclick = () => go({ name: "section", id: view.sectionId });
  $("iSave").onclick = async () => {
    const name = $("iName").value.trim(); if (!name) return toast("Donnez un nom à l'élément");
    const link = $("iLink").value.trim();
    if (link && !/^https?:\/\//i.test(link)) return toast("Le lien doit commencer par https://");
    const row = { name, media_type: media.type, media_url: media.url || null, poster_url: media.type === "video" ? (media.poster || null) : null, link_url: link || null, visible: $("iVisible").checked };
    let error;
    if (it) {
      ({ error } = await supabase.from("items").update(row).eq("id", it.id));
      if (!error && it.media_url !== row.media_url) await removeStored(it.media_url);
      if (!error && it.poster_url && it.poster_url !== row.poster_url) await removeStored(it.poster_url);
    } else {
      const pos = Math.max(0, ...itemsOf(view.sectionId).map((x) => x.position)) + 1;
      ({ error } = await supabase.from("items").insert({ ...row, section_id: view.sectionId, position: pos }));
    }
    if (error) return fail(error, "Enregistrement");
    toast("Enregistré"); view = { name: "section", id: view.sectionId }; refresh();
  };
  if (it) {
    $("iDel").onclick = () => $("iDelBox").hidden = false;
    $("iDelNo").onclick = () => $("iDelBox").hidden = true;
    $("iDelYes").onclick = async () => {
      const { error } = await supabase.from("items").delete().eq("id", it.id);
      if (error) return fail(error, "Suppression");
      await removeStored(it.media_url); await removeStored(it.poster_url);
      toast("Élément supprimé"); view = { name: "section", id: view.sectionId }; refresh();
    };
  }
}

function settingsView() {
  app.innerHTML = `
  <button class="btn ghost" id="back" style="align-self:flex-start;height:34px">${I.back} Rubriques</button>
  <div class="panel">
    <b style="font-weight:500">Réglages</b>
    <label class="field">Numéro WhatsApp<input id="wa" value="${esc(settings.whatsapp_number)}" inputmode="tel"></label>
    <label class="field">Slogan<input id="slogan" value="${esc(settings.slogan)}"></label>
    <label class="field">Identifiant de l'assistante ElevenLabs<input id="agent" value="${esc(settings.elevenlabs_agent_id)}"></label>
    <p class="hint">Grâce utilise cet identifiant. Ne le changez que si vous créez une autre assistante sur ElevenLabs.</p>
    <button class="btn full" id="save">Enregistrer</button>
  </div>`;
  $("back").onclick = () => go({ name: "home" });
  $("save").onclick = async () => {
    const row = { whatsapp_number: $("wa").value.trim(), slogan: $("slogan").value.trim(), elevenlabs_agent_id: $("agent").value.trim(), updated_at: new Date().toISOString() };
    if (!row.whatsapp_number || !row.elevenlabs_agent_id) return toast("Le numéro et l'identifiant sont obligatoires");
    const { error } = await supabase.from("settings").update(row).eq("id", 1);
    if (error) return fail(error, "Enregistrement"); toast("Réglages enregistrés"); refresh();
  };
}

/* ---------- Démarrage ---------- */
async function boot() {
  const { data } = await supabase.auth.getSession();
  session = data.session;
  if (!session) return loginView();
  if (!(await isAdmin())) {
    $("topActions").hidden = false;
    app.innerHTML = '<div class="panel"><b style="font-weight:500">Accès refusé</b><p class="hint">Ce compte n\'a pas les droits d\'administration. Connectez-vous avec le compte administrateur.</p></div>';
    return;
  }
  refresh();
}
$("logout").onclick = async () => { await supabase.auth.signOut(); };
supabase.auth.onAuthStateChange((evt, s) => {
  if (evt === "SIGNED_IN" || evt === "SIGNED_OUT") { session = s; view = { name: "home" }; boot(); }
});
boot();
